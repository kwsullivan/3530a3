SELECT * FROM university;
SELECT * FROM degree;
SELECT * FROM country;
SELECT * FROM agents;
SELECT * FROM degree_offered;
SELECT * FROM recruits_from;